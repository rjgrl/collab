---
id: task-alumni-profile-photo
type: task-spec
status: draft
title: Show and manage alumni profile photos for authorized trackers
---

## Request

Show an alumnus's profile picture when authorized staff view the alumni detail page. Allow only Super Admins and the faculty member directly assigned to that alumnus to upload, replace, or remove the photo. Alumni retain their existing self-service photo controls.

## Product

- The alumni detail header shows a read-only avatar beside the alumnus name, with initials when no photo exists.
- Eligible staff see a "Change photo" action opening a focused dialog for upload/replace/remove.
- Other administrators, department/college heads, unassigned faculty, and unrelated faculty may view photos only when they can view the alumni record; they cannot change them.
- Upload, replacement, and removal errors stay in the dialog and successful changes refresh the header.

## Design

- Reuse the existing protected alumni-image evidence storage and file validation instead of creating a second photo store.
- Add one server authorization helper used by both image upload and image deletion: permit `super_admin`, the alumnus themself, or the active faculty record whose id equals `Alumni.assignedFacultyId`; retain existing scope and permission checks as additional gates.
- Keep direct photo delivery authenticated and harden it to the same alumni scope used by the detail page.
- Render the avatar in the detail header and move the existing image EvidencePanel into a focused dialog; supporting evidence remains a separate page card.
- Audit existing file upload/delete actions; no plaintext or public-photo change is introduced.

## Deferrals

- No bulk photo editing and no avatar column in the alumni directory.
- No automatic photo import from Atlas or external identity providers.
