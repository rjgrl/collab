---
id: task-ui-redesign
type: task-spec
status: done
title: "Declutter the UI: calm sign-up, summary-first Account, same patterns app-wide"
---

## Request

Owner: "Redesign the overall UI of the system, especially the Account page and sign up page
because it looks too cluttered."

## Product

- Sign-up: calm single page (owner chose option B over three steps). Numbered groups (About you,
  Contact, Your studies, Password); optional fields (middle name, suffix, Facebook) behind
  "+ Add" links; helper text only where it prevents a mistake or on error; password checklist as
  a single row of chips; Google button hidden entirely when Google sign-in is off. Still one
  page, same fields, same validation; keeps the "fits 1440x900" goal.
- Account (Settings > Account): read first (owner chose option A). Header with photo (camera
  button), name, email + verification status, role. Cards of label/value rows: Personal details
  (Edit), Contact (email Change, phone Add/Change), Sign-in & security (password Change,
  authenticator Manage). Each action opens a small dialog with only that form. Alumni get the
  same page (same component).
- App-wide, same identity (navy, Inter): one-line page descriptions; long policy notes moved into
  short muted footnotes; single-row filter toolbars; styled file pickers instead of native
  inputs; forms that are not the page's main task open in dialogs (evidence upload, employment);
  detail pages read first.

## Design

- Shared primitives in `apps/web/src/components`: `SummaryCard` + `DetailRow`, `OptionalFields`
  (disclosure "+ Add …"), `FilePicker` (styled button + chosen file name, keeps a real
  `<input type=file>` for accessibility), password checklist chip layout (same list semantics and
  live region).
- Account edits reuse the existing endpoints (`PATCH /auth/profile`, `PATCH /auth/password`,
  email change, photo upload); no API change.
- Accessible names change where layout changes; browser tests are updated in the same commit,
  and axe WCAG 2.2 AA light/dark plus desktop/mobile stay green.

## Confirmed implementation detail

- Phone edits sit under Contact although the API saves them with personal details; the focused
  contact dialog continues to call the existing profile endpoint.

## Deferrals

- No colour, type or layout-system changes (owner chose "same patterns", not a visual refresh).
