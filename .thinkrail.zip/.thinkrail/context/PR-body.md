## Summary

Five owner-requested units, a review-and-hardening pass, and dependency patches. One commit per unit:

```text
feat(auth)          password rules defined once → live checklist; compact one-page sign-up
feat(audit)         Alumni see own entries; actor roles recorded at event time; readable summaries
feat(roles)         Super Admin edits a member's role by exact permission-set match; role Notes
feat(integrations)  credentials AES-256-GCM encrypted in DB, write-only, provider-tested before save
feat(backups)       encrypted verified backups, schedule, guarded in-app restore with rollback
fix                 review gaps: maintenance allowlist, backup exclusions, Drive copy, import, ...
fix                 restore heartbeat, real provider checks, scheduler lock order, CI MongoDB
build(deps)         zod, mongoose, multer + overrides → pnpm audit clean
merge main          keeps this branch's (stricter) local MFA pause handling
feat(api)           /api/v1 + OpenAPI 3.1 generated from one route table; /api deprecated alias
feat(db)            references enforced on every write; nightly integrity scan
feat(backups)       stale-backup alerts; redacted tool errors and restore failure reasons
feat(web)           calm numbered sign-up with optional-field disclosures and password chips
feat(web)           read-first Account summary cards with focused edit dialogs
feat(web)           read-first Alumni details and shared accessible styled file pickers
test(web)           desktop/mobile, light/dark, viewport and axe coverage for the redesign
```

One route table feeds three consumers:

```text
packages/contracts/src/api-routes.ts
├── apps/web/src/lib/api.ts            # typed client (type-level test guards it)
├── docs/api/openapi.json              # pnpm openapi; pnpm test fails when stale
└── apps/server/src/api-routes.test.ts # every route served on /api/v1 and /api
```

Saving integration credentials (enable and update):

```text
POST /api/integrations/:key/enable
  requireAdministrator(integrations.write)    # MFA-verified
  validate required fields + formats
  testIntegrationConnection(provider)         # live check; failure → 400, nothing stored
  seal each secret (AES-256-GCM, AAD = integration:<key>:<field>)
  store ciphertext + 4-char hints + key fingerprint
  audit (no secret values)
```

Restore:

```mermaid
sequenceDiagram
    participant SA as Super Admin
    participant API
    participant DB as MongoDB
    SA->>API: POST /api/backups/:id/restore (TOTP + "RESTORE")
    API->>API: step-up TOTP, schema + key fingerprint checks, lock
    API->>DB: verified pre-restore backup
    API->>DB: maintenance on (non-admin API → 503), heartbeat every 30 s
    API->>DB: mongorestore --drop, swap upload files, migrate, delete sessions
    alt any step fails
        API->>DB: restore pre-restore backup
    end
    API->>DB: maintenance off, audit + restore-log.jsonl
```

## Evidence

- **Before:** `pnpm test` 280; reCAPTCHA check read `error_codes` (Google sends `error-codes`) so any secret passed; CI pinned MongoDB `9.0.0`, which was never published; `pnpm audit` 13 advisories (9 high); `test:forms-db` failing at forms-local.ts:283.
  **After:**
  - `pnpm check` → green, 0 warnings
  - `pnpm test` → 398/398
  - `pnpm test:browser` → 87 passed, 1 skipped (desktop-only viewport test on mobile); axe WCAG 2.2 AA light/dark
  - Real MongoDB: `test:backup-local`, `test:integrations-local`, `test:integrity-local`, `test:completion-db`, `test:forms-db`, `test:scope-local`, `test:security-db`, `test:faculty-local`, `test:contacts-local`, `test:reports-local`, `test:pentest-local` → PASS
  - `docs/api/openapi.json` → valid OpenAPI 3.1 (Redocly); `pnpm db:check-references` on the local dev database → no broken references
  - CI path (`CI=true`, local mongod stopped, in-memory MongoDB 9.0.2): backup, integrations, completion → PASS
  - `pnpm audit --audit-level=moderate` → no known vulnerabilities; `pnpm check:secrets` → clean; build + production/server build checks → PASS

Restore proof (backup-local): back up → mutate data and files → HTTP restore with a generated TOTP → data and files equal the backup, all sessions deleted. Forced failure at the files step → rolled back to the pre-restore state.

## Merge Danger

**Door:** one-way for data, two-way for code.

Migration writes explicit integration rows on existing databases (previous implicit defaults); fresh installs start with integrations disabled. Integration credentials move from env to the encrypted DB in production; env credential variables are ignored there. The in-app restore can replace the live database by design (owner-approved, guarded).

**Blast Radius:** wide.

- **Deploy needs new server env:** `INTEGRATION_ENCRYPTION_KEY` (required in production, 64 hex, distinct from other keys). For backups: `BACKUP_ENCRYPTION_KEY`, absolute `BACKUP_DIR` outside `UPLOAD_DIR`, `MONGODB_TOOLS_DIR` (`pnpm tools:mongodb`).
- **After deploy:** re-enter integration credentials in Settings › Integrations (each is tested against the provider before saving); run `pnpm db:migrate`.
- **Removed:** `PATCH /api/integrations/:key` (enabled integrations without credentials).
- **Password policy** now requires upper, lower, number and special character (owner choice); existing passwords keep working until changed.
- **Sessions:** a restore signs everyone out; role permission changes sign out that role's members (note/name edits no longer do).
- **API:** web calls `/api/v1`; old `/api` paths still work with `Deprecation` headers. Before removing the alias: move the Forms Apps Script to `/api/v1/...` and migrate stored `/api/files/...` image URLs. Google OAuth stays at `/api/auth/google*`.
- **Writes:** any create/update pointing at a missing record now fails with 409 instead of storing a dangling reference.
- **UI:** sign-up, Account, managed Alumni details, and file-upload controls changed layout and accessible interaction patterns without changing API contracts. The full browser suite covers desktop/mobile and light/dark axe checks.
- **Not done:** Drive backup copies are not pruned; backups assume a single host or a shared `BACKUP_DIR`.
