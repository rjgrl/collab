---
id: task-tracking-table-pagination
type: task-spec
status: draft
title: Present alumni tracking history as a paginated table
---

## Request

Replace the Tracking event list on an alumnus detail page with a table and pagination.

## Product

- The table is newest first and shows Date, Status, Tracker, Source, and Notes.
- Users can select 10, 25, or 50 rows per page and move through numbered server-side pages with a visible total count.
- Empty, loading, error, and narrow-screen states remain usable and accessible.
- Existing Mark tracked / Mark untracked controls remain below the history and return the table to page 1 after a successful event.

## Design

- Add a GET route beside the existing POST `/alumni/:alumniId/tracking-events` with `page` and `pageSize` query input and `{ items, page, pageSize, total }` output.
- Enforce the existing scoped `alumni.read` boundary before querying; resolve `createdById` to a safe tracker display name and use "Not recorded" for historical missing actors.
- Sort by `recordedAt desc, _id desc`, use `countDocuments`, `skip`, and `limit`, and support only page sizes 10/25/50.
- Keep the existing detail response field for API compatibility, but let the web detail query opt out of embedded tracking events so the paginated UI does not load the full history twice.
- Reuse shared table and pagination primitives and keep notes wrapped rather than truncated beyond recovery.

## Deferrals

- No tracking-event editing/deletion, date filtering, or export in this change.
