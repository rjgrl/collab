---
id: task-five-units
type: task-spec
title: Sign-up checklist, audit log, roles, integrations, backup/restore
status: done
---

# Request

Five ordered units from the user's brief (1 → 5), each gated by `pnpm check`, `pnpm test`,
`pnpm test:browser` plus unit-specific checks. The brief itself is the accepted design.

# Product

- Unit 1: password policy option **B** chosen by the user (uppercase, lowercase, digit,
  special character + 15–128 length + server-side common/breach check). Deviation from
  NIST SP 800-63B recorded in docs/decisions.md.
- Units 2–5: as specified in the brief (alumni-scoped audit, role snapshots, readable labels;
  Super Admin role edit with exact-match role; Note relabel; encrypted integration credentials
  default-disabled; encrypted backup/restore with maintenance mode).

# Design

- Requirements list is defined once in `packages/contracts/src/password-policy.ts`
  (`{ id, label, test }`); `newPasswordSchema` is built from it.
- "Special character" = any code point that is not a letter, number, combining mark or
  whitespace (`/[^\p{L}\p{N}\p{M}\s]/u`), so emoji and Unicode punctuation count.
- Character-class tests use Unicode properties (`\p{Lu}`, `\p{Ll}`, `\p{Nd}`) so non-ASCII
  letters count.

# Unconfirmed assumptions

- Existing stored passwords are not re-validated; the new rules apply on sign-up, reset and change.

# Deferrals

- SMS integration stays out of scope ("Not connected").
- Restore from uploaded files is out of scope.
