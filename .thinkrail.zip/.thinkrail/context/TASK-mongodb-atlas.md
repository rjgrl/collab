---
id: task-mongodb-atlas
type: task-spec
status: draft
title: Use MongoDB Atlas for hosted application databases
---

## Request

Use MongoDB Atlas for hosted environments while keeping the local replica set for development and tests. Do not connect to Atlas or migrate data on this device. Provide commands for a later migration from the separate presentation-data device.

## Product

- Staging/production deployment documentation uses a named Atlas database, TLS, restricted credentials, and an Atlas network-access rule.
- Local development and automated tests continue to use the isolated `rs0` database on port 27018.
- Operators get a copy/verification runbook for later migration without placing either connection string in source control or shell history examples.

## Design

- Preserve `DATABASE_URL` as the sole runtime database contract; the current production validator already accepts credentialed `mongodb+srv` TLS URLs.
- Add an Atlas operations runbook covering least-privilege database user creation, network access, connection-string placement, preflight transaction verification, maintenance/drain, `mongodump`/`mongorestore` commands using private environment variables, migrations, reference scan, count verification, application smoke tests, rollback, and credential cleanup.
- Reference the pinned MongoDB Database Tools installer already used by backup operations.
- Do not modify local setup scripts to point at Atlas and do not add Atlas credentials, project IDs, API keys, or live network calls.

## Deferrals

- Actual Atlas cluster provisioning, IP allowlisting, secret entry, and data migration happen later on the presentation-data device.
- Atlas backups, monitoring, scaling tier, and formal RPO/RTO remain deployment decisions.
